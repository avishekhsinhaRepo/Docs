#!/usr/bin/perl

$| = 1; #Turns off output buffering

while (<STDIN>) {
	s/-/./g; # Replaces dashes with dots globally
	print $_;
}
